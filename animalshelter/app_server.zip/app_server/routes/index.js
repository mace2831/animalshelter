var express = require('express');
var router = express.Router();
const ctrlMain = require('../controllers/main');

/* GET home page */
router.get('/', ctrlMain.index);

router.get('/api/animals', async (req, res) => { // Ensure this path matches with the app.js configuration
  try {
    const animals = await Animal.find();
    res.json(animals);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Route to serve animal details page using rec_num
router.get('/animals/:recNum', async (req, res) => { // Ensure this path matches the frontend fetch request
  try {
    console.log(`Request for animal details received: ${req.params.recNum}`);
    const animal = await Animal.findOne({ rec_num: req.params.recNum });
    if (!animal) {
      console.log('Animal not found');
      return res.status(404).send('Animal not found');
    }
    console.log('Animal found:', animal);
    res.render('animalDetail', { animal });
  } catch (err) {
    console.error('Error fetching animal details:', err);
    res.status(500).send(err.message);
  }
});


module.exports = router;