const animalsEndpoint = 'http://localhost:3000/api/animals';
const options ={
    method: 'GET',
    headers: {
        'Accept': 'application/json'
    }
}

const Animal = require('../../app_api/models/animals');



/*GET travel view */
const animals = async function(req, res, next){
    
    await fetch(animalsEndpoint, options)
        .then(res => res.json())
        .then(json => {
            //console.log(json);
            let message = null;
            if(!(json instanceof Array)){
                message = 'API lookup error';
                json = [];
            } else {
                if(!json.length){
                    message = 'No animals exist in our database!';
                }
            }
            res.render('animals', {title: 'Animal Shelter', trips: json});
        })
        .catch(err => res.status(500).send(e.message));
    
};

// Controller to fetch all animals
exports.animalsList = async (req, res) => {
  try {
    const animals = await Animal.find();
    res.json(animals);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Controller to add a new animal
exports.animalsAddAnimal = async (req, res) => {
  try {
    const newAnimal = new Animal(req.body);
    await newAnimal.save();
    res.status(201).json(newAnimal);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

// Controller to fetch animal by rec_num
exports.animalsFindByRec = async (req, res) => {
  try {
    const animal = await Animal.findOne({ rec_num: req.params.rec_num });
    if (!animal) {
      return res.status(404).json({ message: 'Animal not found' });
    }
    res.json(animal);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

module.exports = {
    animals
}